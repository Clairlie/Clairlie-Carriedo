const navLinks = document.querySelectorAll('nav a');

function animateNav() {
  navLinks.forEach(link => {
    link.addEventListener('click', () => {
      link.style.transform = 'scale(1.1)';
      setTimeout(() => {
        link.style.transform = 'scale(1)';
      }, 200);
    });
  });
}

animateNav();
